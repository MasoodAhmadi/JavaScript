// jQuery code below
// Look https://jquery.com/ for more info
$(document).ready(function () {
  // after (document).ready, put code that loads when page is loaded

  // This adds a welcome text to a element with id #title_div
  // If you look in index.html, you can see that there is a corresponding element
  // near bottom of the code
  $("#title_div").html("<h1>Tervetuloa!</h1>")

  // Note: when selecting elements in jQuery,
  // # (hashtag) translates to "id", and . (dot) translates to "class"

  // When #home element is clicked
  $("#home").click(function () {
    location.reload() // refresh page
  });

  $("#temperature").click(function () {
    $("#title_div").html("<h1>Temperature</h1>")
    $("#explanation_div").html("Temperature data below")
    hereherehere
    var dt = new Date()
    var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds()
    $("#data_div").html(time)
  });

  $("#wind_speed").click(function () {
    $("#title_div").html("<h1>Wind Speed</h1>")
    $("#explanation_div").html("Wind speed data below")

    var dt = new Date()
    var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds()
  });

  $("#frontend_3").click(function () {
    $("#title_div").html("<h1>Fetching into Api</h1>")

    $("#explanation_div").html(`
      This page is for Frontend 3 assignment.
      Because we dont have data from Pekka's backend yet,
      we cannot utilize that.
      Instead, the assignment is to fetch some data from *any* source
      and display it on this page.
      The data should appear below this text. You are free to style it as you like
      (i.e. inside a <a href="https://www.w3schools.com/html/html_tables.asp">table</a>)
    `)
    // Get data from remote using jQuery.ajax()
    // http://api.jquery.com/jquery.ajax/
    // Replace contents of the variable below with data from an ajax call
    const data = 'Data here';
    const API_KEY = 'LC6jCncBaHDoTLyao6DR'
    $.ajax({
      url: `http://webapi19sa-1.course.tamk.cloud/v1/weather`,
      dataType: 'json',
    }).done(function(data) {
      console.log('data in the console:', data)
      $("#data_div").html(JSON.stringify(data))
    });
  });
});