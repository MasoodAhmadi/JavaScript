//My own API which I have made in JAVASCRIPT.
const myApi = function (API_Mine) {
  $.ajax({
    url: API_Mine,
    dataType: "json"
  }).done(function (data) {
    console.log("data in the console:", data);
    $("#data_div").html(`<canvas id="myChart" width="600" height="300"></canvas>`);
    $("#chart_div").html("");

    var windspeedValuesData = data
      .filter(item => typeof item.data.Wind_1 !== "undefined")
      .map(item => ({
        x: new Date(item.date_time),
        y: item.data.Wind_1
      }))
      .slice(0, 20);
    var ctx = document.getElementById("myChart").getContext("2d");
    var myChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: windspeedValuesData.map(item => item.x),
        datasets: [{
          label: "Wind Speed",
          data: windspeedValuesData,
          fill: false,
          borderColor: 'red',
          borderWidth: 4
        }]
      }
    });
  });
}