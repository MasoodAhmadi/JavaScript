$(document).ready(function () {
  $('#title_div').html(
    '<h1>Weather Station </h1> <img id="img" src="iot-2019.png" class="img-responsive"> <div class="media border p-3"><img src="Masood.jpg" alt="John Doe" class="mr-3 mt-3 rounded-circle" style="width:60px;"><div class="media-body"><h4>Masood Ahmadi <small><i>Posted on 7th May, 2019</i></small></h4><p>Well lets give a brief introduction for this junior developer,Its me Masood Ahmadi studying Software Engineering and have been trying to design  the web site for the Weather Station will continue to search some good information from the web and modify my Web, Last I have got my own value of wind speed from my own API..</p>'
  );

  //These are the API which I send values into, "API_Mine" is my own backend API of which I send wind speed value into that URL.
  const api = `http://webapi19sa-1.course.tamk.cloud/v1/weather`;

  const API_address_humidity_out = `http://webapi19sa-1.course.tamk.cloud/v1/weather/humidity_out`;
  const API_Address_Temperature = `http://webapi19sa-1.course.tamk.cloud/v1/weather/temperature`;
  const API_Address_Last20Measurements = `http://webapi19sa-1.course.tamk.cloud/v1/weather/Last_20_Measurements`;
  const API_Mine = `http://webapi19sc-2.course.tamk.cloud/v1/weather`;


  // refresh page
  $('#home').click(function () {
    location.reload();
  });
  //Temperature value works OK.
  $('#temperature').click(function (API_Mine) {
    $('#title_div').html('<h1>Temperature</h1>');
    $('#explanation_div').html('Temperature data below');
    var dt = new Date();
    var time = dt.getHours() + ':' + dt.getMinutes() + ':' + dt.getSeconds();
    $('#data_div').html(time);
    drawTemperatureData(api);
  });

  //free choice measurements value 
  $('#last_20_Measurements').click(function () {
    $('#title_div').html('<h1>Picking a Measurement</h1>');
    $('#explanation_div').html('');
    $.ajax({
      url: API_Address_Last20Measurements,
      dataType: 'json'
    }).done(function (data) {
      console.log(data);
      let html = ` <p>Pick a time interval:</p>
       <p><select id="selectInterval" class="form-control selcls">
         <option value="0">Live</option>
         <option value="24" selected>24 hours</option>
         <option value="48">48 hours</option>
         <option value="72">72 hours</option>
         <option value="168">1 week</option>
         <option value="744">1 month</option>
       </select></p>
       <div id="selectNameDiv">
         <p>Pick a measurement:</p><p><select id='selectName' class='form-control selcls'></select></p>
         <button id="updateName" type="button" class="btn btn-primary">Update</button>`;
      $('#data_div').html(html);
    });
    var dt = new Date();
    var time = dt.getHours() + ':' + dt.getMinutes() + ':' + dt.getSeconds();
    LastData(api);
  });

  //Last 500 measurments works OK.
  $('#lastValue').click(function () {
    $('#title_div').html('<h1>Last 500 measurments</h1>');
    $('#explanation_div').html('lastValue');
    $.ajax({
      url: api,
      dataType: 'json'
    }).done(function (data) {
      console.log(data);
      let html = `<table class ="table table-striped"> 
                       <thead> 
                       <tr>
                       <th>Date </th>
                        <th> Time </th>
                        <th>Name</th>
                        <th>Value</th>
                        </tr></thead><tbody>`;
      data.forEach(element => {
        let d = new Date(element.date_time);
        let time = d.toLocaleDateString();
        let date = d.toLocaleTimeString();
        html += `<tr><td>${time}</td><td>${date}`;
        for (name in element.data) {
          html += `<td>${name}</td><td>${element.data[name]}</td></tr>`;
        }
      });
      html += '</tbody></table>';
      $('#data_div').html(html);
      $("#chart_div").hide();
    });
  });
  //Last 20 Humidity works OK.

  $("#Humidity_out").click(function () {
    $("#title_div").html("<h1>Last 20 Humidity out</h1>");
    $("#explanation_div").html("");
    Humidityout(API_address_humidity_out);
    $("#chart_div").hide();


  });
  //wind speed works OK.
  $("#wind_speed").click(function () {
    $("#title_div").html("<h1>Wind Speed</h1>")
    $("#explanation_div").html("Wind speed data below")
    var dt = new Date()
    var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds()
    $("#data_div").html(
      '<div class="chartboard"> <canvas id="myChart" width="200" height="400"></canvas></div>'
    );
    $("#chart_div").hide();

    wind_speed(api);
  });
  //Temperature works OK.
  $("#temperature").click(function () {
    $("#title_div").html("<h1>Temperature</h1>")
    $("#explanation_div").html("Temperature data below")
    var dt = new Date()
    var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds()
    $("#data_div").html(time)
    $("#explanation_div").html("Temperature table & chart")
    drawTemperatureData(API_Address_Temperature);
    $("#chart_div").show();


  });
  //Value into my own API works OK.
  $('#Wind_my_speed').click(function () {
    $('#title_div').html('<h1>Values from my own API of wind speed</h1>');
    $('#explanation_div').html(`wind_speed chart`);
    myApi(API_Mine);
    $("#chart_div").hide();

  });

  //Humidity chart works OK.
  $('#Humidity').click(function () {
    $('#title_div').html('<h1>Humidity</h1>');
    $('#explanation_div').html(`
      Humidity Chart
    `);
    const data = 'Data here';
    const API_KEY = 'LC6jCncBaHDoTLyao6DR';
    $.ajax({
      url: api,
      dataType: 'json'
    }).done(function (data) {
      console.log('data in the console:', data);
      $('#data_div').html(
        '<canvas id="myChart" width="400" height="200"></canvas>'
      );
      $("#chart_div").hide();

      var humidityValuesData = data
        .filter(item => typeof item.data.humidity_out !== 'undefined')
        .map(item => ({
          x: new Date(item.date_time),
          y: item.data.humidity_out
        }))
        .slice(0, 50);
      console.log('humidityValue', humidityValuesData);
      var ctx = document.getElementById('myChart').getContext('2d');
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: humidityValuesData.map(item => item.x),
          datasets: [{
            label: 'Humidity',
            data: humidityValuesData,
            fill: false,
            borderColor: 'red',
            borderWidth: 4
          }]
        }
      });
    });
  });
});