//My Humidity values which I have made in JAVASCRIPT.

function Humidityout(api) {
    console.log("Inside Humdity_out");
    $.ajax({
        url: api,
        dataType: "json"
    }).done(function (data) {
        console.log("data fetch done", data);
        const tableStart = `<table class="table table-striped" id="latest_values" class="display" style="width:100%">
           <thead>
               <tr>
                   <th>ID</th>
                   <th>Time</th>
                   <th>Value</th>
               </tr>
           </thead>
           <tbody>
               `;
        let tableContent = '';
        console.log(typeof data);
        data.forEach(function (item) {
            console.log("item: ", item);
            tableContent +=
                `<tr>
              <td>${item.device_id}</td>
              <td>${item.date_time}</td>
              <td>${item.humidity_out}</td>
          </tr>`;
        });
        const tableEnd = `
          </tbody>
          </table>`;
        const table = tableStart + tableContent + tableEnd;
        $("#data_div").html(table);
    });
}