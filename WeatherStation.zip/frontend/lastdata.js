    const LastData = function (api) {
        var e = $("#selectName").val();
        "undefined" !== e && null != e || getNames(t).done(function () {
            e = $("#selectName").val(), console.log(e + " getnames ")
        });
        var a = $("#selectInterval").val(),
            l = "";
        l = $.isNumeric(a) ? t + "/" + e + "/" + a : t + "/" + e, console.log(l), $.getJSON(l, function (api) {
            let a = [],
                l = [],
                o = "<table class='table table-striped'><thead><tr><th>Date</th><th>Time</th><th>Value</th></tr></thead><tbody>";
            t.forEach(t => {
                let o = new Date(t.date_time),
                    n = o.toLocaleDateString(),
                    i = o.toLocaleTimeString();
                a.push(n + " " + i), l.push(t[e])
            }), t.reverse(), t.forEach(t => {
                let a = new Date(t.date_time),
                    l = a.toLocaleDateString(),
                    n = a.toLocaleTimeString();
                o += "<tr><td>" + l + "</td><td>" + n + "</td><td> " + t[e] + "</td></tr>"
            }), o += "</tbody></table>", $("#data_div").html(o), $("#chart_div").show(), $("#data_div").show();
            let n = $("#chart_canvas");
            new Chart(n, {
                type: "line",
                data: {
                    labels: a,
                    type: "time",
                    datasets: [{
                        label: "Data: " + e,
                        data: l,
                        fill: !1,
                        borderColor: "#1E90FF"
                    }]
                },
                options: {
                    animation: !1,
                    showLines: !0,
                    events: [],
                    scales: {
                        yAxes: [{
                            display: !0,
                            ticks: {
                                beginAtZero: !0
                            }
                        }]
                    }
                }
            })
        })
    };